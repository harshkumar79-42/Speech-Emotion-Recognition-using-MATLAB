function coeffs = compute_mfcc(x, fs, numCoeffs)
winLength = round(0.03*fs);
hopLength = round(0.01*fs);
nfft = 2^nextpow2(winLength);
if exist('mfcc','file') == 2
    coeffs = mfcc(x, fs, 'WindowLength', winLength, 'OverlapLength', winLength-hopLength, 'NumCoeffs', numCoeffs, 'LogEnergy','Ignore');
else
    S = melSpectrogram(x, fs, 'WindowLength', winLength, 'OverlapLength', winLength-hopLength, 'FFTLength', nfft);
    S = log10(S + 1e-6);
    coeffs = dct(S);
    coeffs = coeffs(1:numCoeffs, :)';
end
end
function out = pad_or_truncate(X, maxLen)
[numF, numFrames] = size(X);
if numFrames < maxLen
    out = [X, zeros(numF, maxLen - numFrames)];
else
    out = X(:,1:maxLen);
end
end
