function [model, acc, confMat] = train_svm(XTrain, YTrain, XTest, YTest, labelNames)
template = templateSVM('KernelFunction','rbf','Standardize',true);
model = fitcecoc(XTrain, YTrain, 'Learners', template, 'Coding', 'onevsall');
pred = predict(model, XTest);
acc = mean(pred == YTest);
confMat = confusionmat(YTest, pred, 'Order', labelNames);
fprintf('SVM Test Accuracy: %.2f%%\n', acc*100);
end
