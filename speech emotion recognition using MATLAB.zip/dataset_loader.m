function [tbl, labelNames] = dataset_loader(datasetPath, sampleRate, numCoeffs, maxSeqLen)
audioExt = {'*.wav','*.flac','*.ogg','*.mp3'}; 
files = [];
labels = {};
labelNames = [];
dirs = dir(datasetPath);
for i = 1:length(dirs)
    if dirs(i).isdir && ~ismember(dirs(i).name,{'.','..'})
        lab = dirs(i).name;
        labelNames{end+1} = lab; %#ok<AGROW>
        d = dir(fullfile(datasetPath, lab));
        for e = 1:length(d)
            if ~d(e).isdir
                [~,~,ext] = fileparts(d(e).name);
                if ~isempty(ext)
                    files{end+1,1} = fullfile(datasetPath, lab, d(e).name);
                    labels{end+1,1} = lab;
                end
            end
        end
    end
end
n = length(files);
seqFeatures = cell(n,1);
avgFeature = cell(n,1);
filepaths = files;
for i = 1:n
    fp = files{i};
    try
        [x, fs] = audioread(fp);
    catch
        warning('Failed to read %s — skipping', fp);
        continue;
    end
    if size(x,2) > 1, x = mean(x,2); end
    if fs ~= sampleRate, x = resample(x, sampleRate, fs); fs = sampleRate; end
    x = x / (max(abs(x)) + eps);
    coeffs = compute_mfcc(x, fs, numCoeffs);
    coeffs_t = coeffs';
    coeffs_p = pad_or_truncate(coeffs_t, maxSeqLen);
    seqFeatures{i} = coeffs_p;
    avgFeature{i} = mean(coeffs,1);
end
tbl = table(filepaths, labels', seqFeatures, avgFeature, 'VariableNames', {'filepath','label','seqFeatures','avgFeature'});
labelNames = unique(labels);
end
