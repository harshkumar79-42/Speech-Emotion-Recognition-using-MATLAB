function [net, acc, confMat] = train_lstm(XTrain, YTrain, XTest, YTest, labelNames, numFeatures, maxSeqLen)
YTrainCat = categorical(YTrain);
YTestCat = categorical(YTest);
numHidden = 128;
layers = [sequenceInputLayer(numFeatures)
          bilstmLayer(numHidden,'OutputMode','last')
          fullyConnectedLayer(numel(labelNames))
          softmaxLayer
          classificationLayer];
options = trainingOptions('adam','MaxEpochs',30,'MiniBatchSize',32,'Shuffle','every-epoch','Verbose',false);
net = trainNetwork(XTrain, YTrainCat, layers, options);
YPred = classify(net, XTest, 'MiniBatchSize', 32);
acc = mean(YPred == YTestCat);
confMat = confusionmat(YTestCat, YPred);
fprintf('LSTM Test Accuracy: %.2f%%\n', acc*100);
end
