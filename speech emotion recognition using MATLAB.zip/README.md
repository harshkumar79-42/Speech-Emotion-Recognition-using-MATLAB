# Speech Emotion Recognition (SER) - MATLAB
This repository contains a self-contained MATLAB project for Speech Emotion Recognition using both traditional ML (SVM) and deep learning (LSTM).
Follow the steps in README for setup and usage.
